/**
 * FVTT 下载改进 - 改进版 views.mjs
 * 
 * 此文件是 FoundryVTT 的 views.mjs 的改进版本，添加了：
 * - 多代理自动切换支持
 * - GitLab 代理支持
 * - 后端统一管理代理列表
 * 
 * 原始路径: App/resources/app/dist/packages/views.mjs
 * 使用方法: 复制此文件覆盖原始文件
 */

import { isNewerVersion } from "../../common/utils/helpers.mjs";
import { PACKAGE_AVAILABILITY_CODES } from "../../common/constants.mjs";
import { World, System, Module, PACKAGE_TYPE_MAPPING } from "./_module.mjs";
import PreviewCompatibility from "./preview-compatibility.mjs";
import { ReleaseData } from "../../common/config.mjs";
import ProgressEmitter from "../components/progress-emitter.mjs";

/** Client transport entry point. Mirror selection and retries live in the backend. */
const FVTT_PROXY_BASE = (process.env.FVTT_PACKAGE_PROXY_URL ?? "https://fvtt-download-cdn.aivu.top").replace(/\/+$/, "");
const FVTT_API_PROXY = FVTT_PROXY_BASE ? FVTT_PROXY_BASE + "/api/fvtt/packages" : "";

const GITHUB_DOMAINS = ["github.com", "raw.githubusercontent.com", "gist.github.com", "gist.githubusercontent.com", "codeload.github.com", "objects.githubusercontent.com", "release-assets.githubusercontent.com", "api.github.com"];
const GITLAB_DOMAINS = ["gitlab.com"];

function checkUrlNeedsProxy(url) {
    try {
        const parsed = new URL(url);
        if (!["http:", "https:"].includes(parsed.protocol)) return {needsProxy: false, type: null};
        const matches = domains => domains.some(domain => parsed.hostname === domain || parsed.hostname.endsWith("." + domain));
        if (matches(GITHUB_DOMAINS)) return {needsProxy: true, type: "github"};
        if (matches(GITLAB_DOMAINS)) return {needsProxy: true, type: "gitlab"};
    } catch { /* Leave relative or invalid URLs alone. */ }
    return {needsProxy: false, type: null};
}

function getProxiedUrl(originalUrl) {
    const {needsProxy, type} = checkUrlNeedsProxy(originalUrl);
    return needsProxy && FVTT_PROXY_BASE ? FVTT_PROXY_BASE + "/proxy/" + type + "/" + originalUrl : originalUrl;
}

export async function getPackages({ type: e = "system" } = {}) {
    const t = PACKAGE_TYPE_MAPPING[e];
    if (!t) throw new Error(`Invalid package type ${e} requested`);
    const { packages: r, owned: a } = await t.getRepositoryPackages();
    return { packages: Array.from(r.values()).map(e => e.vend()), owned: a };
}

export async function getPackageFromRemoteManifest({ type: e = "module", manifest: t = "" } = {}) {
    const r = PACKAGE_TYPE_MAPPING[e];
    return await r.fromRemoteManifest(t);
}

export async function checkPackage({ type: e, id: t, manifest: r, forceSidegrade: a = false, strict: o = true } = {}) {
    const s = PACKAGE_TYPE_MAPPING[e];
    if (!s) throw new Error(`Invalid package type ${e} requested`);
    const n = s.get(t, { strict: false });
    if (!r) {
        if (!n.manifest) throw new Error(`The ${e} ${t} has no manifest URL provided`);
        r = n.manifest;
    }
    const i = await s.check(r, n, { strict: o });
    const c = i.remote;
    let p;
    if (c && (t ||= c.id), (n || a) && (p = await s.fromRepository(t), c && a && p && c.sidegrade(c, p)), n && p && (!c || isNewerVersion(p.version, c.version)) && (i.trackChange = n.suggestTrackChange(p), i.trackChange && i.error && 404 === i.errorCode && delete i.error, i.trackChange)) return i;
    if (!c) return i;
    if ("module" === e) {
        i.systemCompatibility = {};
        for (const { id: e, compatibility: t } of c.relationships?.systems ?? []) {
            const r = System.get(e, { strict: false });
            r && (i.systemCompatibility[e] = { id: e, title: r.title, compatible: c.constructor.testDependencyCompatibility(t, r) && !r.unavailable });
        }
    }
    if (i.isUpgrade || i.isDowngrade) return i;
    if (n) { n.sidegrade(c, p) && (i.hasSidegraded = true); }
    return i;
}

/**
 * 安装包 (带代理支持)
 * [MODIFIED] 使用手动配置的代理列表
 */
export async function installPackage({ type: e, id: t, manifest: r, force: a = false }) {
    const o = PACKAGE_TYPE_MAPPING[e];
    if (!o) throw new Error(`Invalid package type ${e} requested`);
    if (!r) throw new Error("A manifest URL must be provided");

    const s = await checkPackage({ type: e, id: t, manifest: r, forceSidegrade: true });
    const n = s.remote;

    if (!n) {
        const t = [`Unable to load valid ${e} manifest data from "${r}"`, s.error].filterJoin("\n");
        throw new Error(t);
    }

    if (t = n.id, s.isDowngrade && !a) throw new Error(`You are currently using a more recent version of ${e} ${n.title} and may not downgrade to an older version`);

    const i = n.availability;
    const c = PACKAGE_AVAILABILITY_CODES;

    if (!a) {
        if (i === c.REQUIRES_CORE_DOWNGRADE) throw new Error(`${e} ${t} version ${n.version} requires an older version of the Foundry Virtual Tabletop software: ${n.compatibility.maximum} or older`);
        if ([c.REQUIRES_CORE_UPGRADE_STABLE, c.REQUIRES_CORE_UPGRADE_UNSTABLE].includes(i)) throw new Error(`${e} ${t} version ${n.version} requires a more modern version of the Foundry Virtual Tabletop software: ${n.compatibility.minimum} or newer`);
    }

    let p, l = n.download;

    if (n.protected) {
        if (p = await o.getProtectedDownloadURL({ type: e, id: t, version: n.version }), "error" === p.status) throw new Error(p.message);
        l = p.download;
    }

    if (!l) throw new Error(`The ${n.title} ${e} does not provide a download URL that can be installed`);

    // [MODIFIED] 使用代理
    const { needsProxy } = checkUrlNeedsProxy(l);
    if (needsProxy) {
        global.logger.info(`[Mirror Fix] Intercepted Download URL: ${l}`);
        l = getProxiedUrl(l);
        global.logger.info(`[Mirror Fix] Using Mirror URL: ${l}`);
    }

    const E = {};
    return new Promise(async (a, s) => {
        let n;
        const { ACTIONS: i, STEPS: c } = CONST.SETUP_PACKAGE_PROGRESS;
        const d = new ProgressEmitter(i.INSTALL_PKG, null, 1, { type: e, id: r, title: t });
        const m = { [c.DOWNLOAD]: "Downloading package", [c.INSTALL]: "Installing package" };

        try {
            const e = await o.install(t, r, l, p, {
                onFetched: () => a(E),
                onProgress: (e, t, r) => {
                    e !== n && (d.nextStep(e, r, { message: `SETUP.PackageProgress${e.titleCase()}` }), n = e);
                    d.emit(t, { log: m[e] });
                },
                onError: (e, t) => {
                    if (e === c.DOWNLOAD) return s(t);
                    d.error(t);
                }
            });

            if (!e) return d.error(new Error("PACKAGE.InstallFailed"), { context: { packageWarnings: { [t]: packages.warnings.toJSON()[t] } } }), void s(new Error("PACKAGE.InstallFailed"));
            d.complete({ context: { pkg: e.vend() } });
        } catch (e) {
            d.error(e);
            s(e);
        }
    });
}

export async function resetPackages() {
    return Module.resetPackages(), System.resetPackages(), World.resetPackages(), { message: "Reset package cache for all package types" };
}

export async function uninstallPackage({ type: e, id: t }) {
    const r = PACKAGE_TYPE_MAPPING[e];
    if (!r) throw new Error(`Invalid package type ${e} requested`);
    const a = r.uninstall(t);
    return a.uninstalled = true, a;
}

export async function lockPackage({ type: e, id: t, shouldLock: r }) {
    const a = PACKAGE_TYPE_MAPPING[e];
    if (!a) throw new Error(`Invalid package type ${e} requested`);
    return a.get(t, { strict: false }).lock(r), { message: `Locked package ${t}` };
}

export async function handlePreviewCompatibility({ release: e }) {
    const t = new PreviewCompatibility(new ReleaseData(e));
    return await t.evaluate(), t.vend();
}

export function handleCreateBackups({ backups: e }) {
    const { packages: t, express: r } = global;
    const { ACTIONS: a, STEPS: o } = CONST.SETUP_PACKAGE_PROGRESS;
    return t.backups.createBackups(e).catch(e => {
        r.io.emit("progress", { action: a.CREATE_BACKUP, step: o.ERROR, error: e.message, stack: e.stack });
    }), {};
}

export function handleCreateSnapshot({ note: e, id: t }) {
    const { packages: r, express: a } = global;
    const { ACTIONS: o, STEPS: s } = CONST.SETUP_PACKAGE_PROGRESS;
    return r.backups.createSnapshot({ note: e, id: t }).catch(e => {
        a.io.emit("progress", { action: o.CREATE_SNAPSHOT, steps: s.ERROR, error: e.message, stack: e.stack });
    }), {};
}

export function handleDeleteBackups({ backups: e }) {
    const { packages: t, express: r } = global;
    const { ACTIONS: a, STEPS: o } = CONST.SETUP_PACKAGE_PROGRESS;
    return t.backups.deleteBackups(e).catch(e => {
        r.io.emit("progress", { action: a.DELETE_BACKUP, step: o.ERROR, error: e.message, stack: e.stack });
    }), {};
}

export function handleDeleteSnapshots({ snapshots: e }) {
    const { packages: t, express: r } = global;
    const { ACTIONS: a, STEPS: o } = CONST.SETUP_PACKAGE_PROGRESS;
    return t.backups.deleteSnapshots(e).catch(e => {
        r.io.emit("progress", { action: a.DELETE_SNAPSHOT, step: o.ERROR, error: e.message, stack: e.stack });
    }), {};
}

export function handleRestoreBackups({ backups: e }) {
    const { packages: t, express: r } = global;
    const { ACTIONS: a, STEPS: o } = CONST.SETUP_PACKAGE_PROGRESS;
    return t.backups.restoreBackups(e).catch(e => {
        r.io.emit("progress", { action: a.RESTORE_BACKUP, steps: o.ERROR, error: e.message, stack: e.stack });
    }), {};
}

export function handleRestoreSnapshot({ snapshotData: e }) {
    const { packages: t, express: r } = global;
    const { ACTIONS: a, STEPS: o } = CONST.SETUP_PACKAGE_PROGRESS;
    return t.backups.restoreSnapshot(e).catch(e => {
        r.io.emit("progress", { action: a.RESTORE_SNAPSHOT, steps: o.ERROR, error: e.message, stack: e.stack });
    }), {};
}
